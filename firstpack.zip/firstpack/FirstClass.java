package firstpack;

public class FirstClass{
	protected void firstClassFun()
	{
		System.out.println("This is firstpack package");
	}
}
