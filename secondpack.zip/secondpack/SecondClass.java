package secondpack;
import firstpack.*;
public class SecondClass extends FirstClass{
	public static void main(String args[])
	{	
		SecondClass fc=new SecondClass();
		fc.firstClassFun();
		
		
	}
}	